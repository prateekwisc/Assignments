ParallelUtils.cmake
========================

Template and some utilities for setting up a new CMake project with CUDA, MPI, and/or OpenMP
